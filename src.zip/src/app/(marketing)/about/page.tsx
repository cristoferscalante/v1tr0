export default function page(){
    return <h1>Pagina para info de empresa</h1>
}