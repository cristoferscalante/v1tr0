export default function page(){
    return <h1>lista / Indice del Blog</h1>
}