export default function page(){
    return <h1>Pagina para gestion de proyectos</h1>
}