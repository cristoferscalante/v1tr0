export default function page(){
    return <h1>Pagina para analisis y visualizacion de datos</h1>
}