export default function page(){
    return <h1>Pagina para desarrollo de sofware</h1>
}