export default function page(){
    return <h1> Inicio de sesión</h1>
}