"use client";

export default function Page() {
    return <div>Dashboard Projects</div>;
}