export default function page(){
    return <h1>Perfil de usuario</h1>
}