export default function page(){
    return <h1>Pagina para chat</h1>
}